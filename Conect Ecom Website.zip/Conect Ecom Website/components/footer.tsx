import Link from "next/link"
import Image from "next/image"

export default function Footer() {
  return (
    <footer className="bg-[#374151] text-white">
      <div className="container mx-auto px-4 md:px-6 py-12">
        <div className="grid md:grid-cols-3 gap-8">
          {/* Logo e Descrição */}
          <div className="md:col-span-1">
            <Image
              src="/images/logo-conect-ecom-nova.png"
              alt="Conect Ecom"
              width={160}
              height={50}
              className="h-10 w-auto mb-4"
            />
            <p className="text-[#9ca3af] text-sm leading-relaxed">
              Transformamos sua loja online em um negócio que vende de verdade. Especialistas em e-commerce com foco em
              resultados.
            </p>
          </div>

          {/* Links Rápidos */}
          <div>
            <h3 className="font-medium text-white mb-4">Links Rápidos</h3>
            <ul className="space-y-2">
              <li>
                <Link href="/servicos" className="text-[#9ca3af] hover:text-white transition-colors text-sm">
                  Serviços
                </Link>
              </li>
              <li>
                <Link href="/portfolio" className="text-[#9ca3af] hover:text-white transition-colors text-sm">
                  Portfólio
                </Link>
              </li>
              <li>
                <Link href="/quem-somos" className="text-[#9ca3af] hover:text-white transition-colors text-sm">
                  Quem Somos
                </Link>
              </li>
              <li>
                <Link href="/blog" className="text-[#9ca3af] hover:text-white transition-colors text-sm">
                  Blog
                </Link>
              </li>
            </ul>
          </div>

          {/* Contato */}
          <div>
            <h3 className="font-medium text-white mb-4">Contato</h3>
            <ul className="space-y-2">
              <li>
                <a
                  href="mailto:contato@conectecom.com.br"
                  className="text-[#9ca3af] hover:text-white transition-colors text-sm"
                >
                  contato@conectecom.com.br
                </a>
              </li>
              <li>
                <a href="tel:+5511999999999" className="text-[#9ca3af] hover:text-white transition-colors text-sm">
                  (11) 99999-9999
                </a>
              </li>
              <li>
                <span className="text-[#9ca3af] text-sm">São Paulo, SP</span>
              </li>
            </ul>
          </div>
        </div>

        {/* Copyright */}
        <div className="border-t border-[#4b5563] mt-8 pt-6">
          <p className="text-[#9ca3af] text-sm text-center">© 2025 Conect Ecom. Todos os direitos reservados.</p>
        </div>
      </div>
    </footer>
  )
}
