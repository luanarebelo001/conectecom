"use client"
import { useState, useEffect } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from "recharts"

interface AnalyticsData {
  breadcrumb_clicks: number
  navigation_events: number
  cta_clicks: number
  page_views: number
}

interface BreadcrumbAnalytics {
  level: number
  clicks: number
  path: string
}

export default function AnalyticsDashboard() {
  const [analyticsData, setAnalyticsData] = useState<AnalyticsData>({
    breadcrumb_clicks: 0,
    navigation_events: 0,
    cta_clicks: 0,
    page_views: 0,
  })

  const [breadcrumbData, setBreadcrumbData] = useState<BreadcrumbAnalytics[]>([])

  useEffect(() => {
    // Simular dados de analytics (em produção, viria de uma API)
    const mockData: AnalyticsData = {
      breadcrumb_clicks: 156,
      navigation_events: 423,
      cta_clicks: 89,
      page_views: 1247,
    }

    const mockBreadcrumbData: BreadcrumbAnalytics[] = [
      { level: 0, clicks: 45, path: "Home" },
      { level: 1, clicks: 67, path: "Home > Serviços" },
      { level: 2, clicks: 34, path: "Home > Serviços > Construção" },
      { level: 2, clicks: 28, path: "Home > Serviços > Otimização" },
      { level: 2, clicks: 22, path: "Home > Serviços > Manutenção" },
    ]

    setAnalyticsData(mockData)
    setBreadcrumbData(mockBreadcrumbData)
  }, [])

  return (
    <div className="p-6 space-y-6">
      <h2 className="text-2xl font-bold text-gray-900">Analytics Dashboard</h2>

      {/* Cards de Métricas */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Cliques em Breadcrumbs</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{analyticsData.breadcrumb_clicks}</div>
            <p className="text-xs text-muted-foreground">+12% em relação ao mês anterior</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Eventos de Navegação</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{analyticsData.navigation_events}</div>
            <p className="text-xs text-muted-foreground">+8% em relação ao mês anterior</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Cliques em CTAs</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{analyticsData.cta_clicks}</div>
            <p className="text-xs text-muted-foreground">+15% em relação ao mês anterior</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Visualizações de Página</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{analyticsData.page_views}</div>
            <p className="text-xs text-muted-foreground">+5% em relação ao mês anterior</p>
          </CardContent>
        </Card>
      </div>

      {/* Gráfico de Breadcrumbs */}
      <Card>
        <CardHeader>
          <CardTitle>Cliques por Nível de Breadcrumb</CardTitle>
        </CardHeader>
        <CardContent>
          <ResponsiveContainer width="100%" height={300}>
            <BarChart data={breadcrumbData}>
              <CartesianGrid strokeDasharray="3 3" />
              <XAxis dataKey="path" />
              <YAxis />
              <Tooltip />
              <Bar dataKey="clicks" fill="#3b82f6" />
            </BarChart>
          </ResponsiveContainer>
        </CardContent>
      </Card>

      {/* Tabela de Detalhes */}
      <Card>
        <CardHeader>
          <CardTitle>Detalhes de Navegação por Breadcrumb</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead>
                <tr className="border-b">
                  <th className="text-left p-2">Caminho</th>
                  <th className="text-left p-2">Nível</th>
                  <th className="text-left p-2">Cliques</th>
                  <th className="text-left p-2">Taxa de Clique</th>
                </tr>
              </thead>
              <tbody>
                {breadcrumbData.map((item, index) => (
                  <tr key={index} className="border-b">
                    <td className="p-2">{item.path}</td>
                    <td className="p-2">{item.level}</td>
                    <td className="p-2">{item.clicks}</td>
                    <td className="p-2">{((item.clicks / analyticsData.breadcrumb_clicks) * 100).toFixed(1)}%</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}
