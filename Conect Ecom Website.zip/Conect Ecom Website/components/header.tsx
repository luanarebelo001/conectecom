"use client"
import { usePathname } from "next/navigation"
import Link from "next/link"
import Image from "next/image"

export default function Header() {
  const pathname = usePathname()

  return (
    <header className="bg-[#f9fafb] border-b border-gray-100 sticky top-0 z-50">
      <div className="container mx-auto px-4 md:px-6">
        <div className="flex items-center justify-between h-16 md:h-20">
          {/* Logo */}
          <Link href="/" className="flex items-center">
            <Image
              src="/images/logo-conect-ecom.png"
              alt="Conect Ecom"
              width={120}
              height={40}
              className="h-8 w-auto drop-shadow-sm"
            />
          </Link>

          {/* Navigation Menu */}
          <nav className="hidden md:flex items-center space-x-8">
            <Link
              href="/"
              className={
                pathname === "/"
                  ? "text-[#3b82f6] font-medium"
                  : "text-[#6b7280] hover:text-[#1f2937] transition-colors"
              }
            >
              Home
            </Link>
            <Link
              href="/servicos"
              className={
                pathname === "/servicos"
                  ? "text-[#3b82f6] font-medium"
                  : "text-[#6b7280] hover:text-[#1f2937] transition-colors"
              }
            >
              Serviços
            </Link>
            <Link
              href="/portfolio"
              className={
                pathname === "/portfolio"
                  ? "text-[#3b82f6] font-medium"
                  : "text-[#6b7280] hover:text-[#1f2937] transition-colors"
              }
            >
              Portfólio
            </Link>
            <Link
              href="/consultoria"
              className={
                pathname === "/consultoria"
                  ? "text-[#3b82f6] font-medium"
                  : "text-[#6b7280] hover:text-[#1f2937] transition-colors"
              }
            >
              Consultoria Gratuita
            </Link>
            <Link
              href="/formulario"
              className={
                pathname === "/formulario"
                  ? "text-[#3b82f6] font-medium"
                  : "text-[#6b7280] hover:text-[#1f2937] transition-colors"
              }
            >
              Formulário de Interesse
            </Link>
            <Link
              href="/quem-somos"
              className={
                pathname === "/quem-somos"
                  ? "text-[#3b82f6] font-medium"
                  : "text-[#6b7280] hover:text-[#1f2937] transition-colors"
              }
            >
              Quem Somos
            </Link>
            <Link
              href="/blog"
              className={
                pathname === "/blog"
                  ? "text-[#3b82f6] font-medium"
                  : "text-[#6b7280] hover:text-[#1f2937] transition-colors"
              }
            >
              Blog
            </Link>
            <Link
              href="/contato"
              className={
                pathname === "/contato"
                  ? "text-[#3b82f6] font-medium"
                  : "text-[#6b7280] hover:text-[#1f2937] transition-colors"
              }
            >
              Contato
            </Link>
          </nav>

          {/* Mobile Menu Button */}
          <button className="md:hidden p-2">
            <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 6h16M4 12h16M4 18h16" />
            </svg>
          </button>
        </div>
      </div>
    </header>
  )
}
