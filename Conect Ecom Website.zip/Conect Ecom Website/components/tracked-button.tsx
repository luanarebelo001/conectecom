"use client"
import { Button } from "@/components/ui/button"
import { usePathname } from "next/navigation"
import type { ReactNode } from "react"
import { useAnalytics } from "../hooks/use-analytics"

interface TrackedButtonProps {
  children: ReactNode
  onClick?: () => void
  trackingData: {
    action: string
    category: string
    label?: string
    destination?: string
  }
  className?: string
  [key: string]: any
}

export default function TrackedButton({ children, onClick, trackingData, className, ...props }: TrackedButtonProps) {
  const pathname = usePathname()
  const { trackCTA } = useAnalytics()

  const handleClick = () => {
    const currentPage = pathname.split("/").pop() || "home"

    trackCTA(
      trackingData.label || children?.toString() || "Unknown Button",
      currentPage,
      trackingData.destination || "unknown",
    )

    if (onClick) {
      onClick()
    }
  }

  return (
    <Button className={className} onClick={handleClick} {...props}>
      {children}
    </Button>
  )
}
