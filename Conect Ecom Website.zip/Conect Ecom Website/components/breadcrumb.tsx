import Link from "next/link"
import { ChevronRight, Home } from "lucide-react"

interface BreadcrumbItem {
  label: string
  href?: string
}

interface BreadcrumbProps {
  items: BreadcrumbItem[]
}

export default function Breadcrumb({ items }: BreadcrumbProps) {
  return (
    <div className="bg-white border-b border-gray-200">
      <div className="container mx-auto px-4 md:px-6 py-4">
        <nav className="flex items-center space-x-2 text-sm">
          <Link href="/" className="flex items-center text-[#6b7280] hover:text-[#3b82f6] transition-colors">
            <Home className="w-4 h-4 mr-1" />
            Home
          </Link>

          {items.map((item, index) => (
            <div key={index} className="flex items-center">
              <ChevronRight className="w-4 h-4 text-[#9ca3af] mx-2" />
              {item.href ? (
                <Link href={item.href} className="text-[#6b7280] hover:text-[#3b82f6] transition-colors">
                  {item.label}
                </Link>
              ) : (
                <span className="text-[#1f2937] font-medium">{item.label}</span>
              )}
            </div>
          ))}
        </nav>
      </div>
    </div>
  )
}
