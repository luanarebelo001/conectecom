"use client"
import { createContext, useContext, useEffect, type ReactNode } from "react"

interface AnalyticsConfig {
  googleAnalyticsId?: string
  facebookPixelId?: string
  gtmId?: string
  enableDevelopmentLogging?: boolean
}

interface AnalyticsContextType {
  config: AnalyticsConfig
  isInitialized: boolean
}

const AnalyticsContext = createContext<AnalyticsContextType | undefined>(undefined)

interface AnalyticsProviderProps {
  children: ReactNode
  config: AnalyticsConfig
}

export function AnalyticsProvider({ children, config }: AnalyticsProviderProps) {
  useEffect(() => {
    // Inicializar Google Analytics 4
    if (config.googleAnalyticsId && typeof window !== "undefined") {
      const script = document.createElement("script")
      script.src = `https://www.googletagmanager.com/gtag/js?id=${config.googleAnalyticsId}`
      script.async = true
      document.head.appendChild(script)

      script.onload = () => {
        window.dataLayer = window.dataLayer || []
        window.gtag = function gtag() {
          window.dataLayer?.push(arguments)
        }
        window.gtag("js", new Date())
        window.gtag("config", config.googleAnalyticsId!, {
          page_title: document.title,
          page_location: window.location.href,
        })
      }
    }

    // Inicializar Facebook Pixel
    if (config.facebookPixelId && typeof window !== "undefined") {
      const script = document.createElement("script")
      script.innerHTML = `
        !function(f,b,e,v,n,t,s)
        {if(f.fbq)return;n=f.fbq=function(){n.callMethod?
        n.callMethod.apply(n,arguments):n.queue.push(arguments)};
        if(!f._fbq)f._fbq=n;n.push=n;n.loaded=!0;n.version='2.0';
        n.queue=[];t=b.createElement(e);t.async=!0;
        t.src=v;s=b.getElementsByTagName(e)[0];
        s.parentNode.insertBefore(t,s)}(window, document,'script',
        'https://connect.facebook.net/en_US/fbevents.js');
        fbq('init', '${config.facebookPixelId}');
        fbq('track', 'PageView');
      `
      document.head.appendChild(script)
    }

    // Inicializar Google Tag Manager
    if (config.gtmId && typeof window !== "undefined") {
      const script = document.createElement("script")
      script.innerHTML = `
        (function(w,d,s,l,i){w[l]=w[l]||[];w[l].push({'gtm.start':
        new Date().getTime(),event:'gtm.js'});var f=d.getElementsByTagName(s)[0],
        j=d.createElement(s),dl=l!='dataLayer'?'&l='+l:'';j.async=true;j.src=
        'https://www.googletagmanager.com/gtm.js?id='+i+dl;f.parentNode.insertBefore(j,f);
        })(window,document,'script','dataLayer','${config.gtmId}');
      `
      document.head.appendChild(script)
    }
  }, [config])

  const contextValue: AnalyticsContextType = {
    config,
    isInitialized: true,
  }

  return <AnalyticsContext.Provider value={contextValue}>{children}</AnalyticsContext.Provider>
}

export function useAnalyticsContext() {
  const context = useContext(AnalyticsContext)
  if (context === undefined) {
    throw new Error("useAnalyticsContext must be used within an AnalyticsProvider")
  }
  return context
}
