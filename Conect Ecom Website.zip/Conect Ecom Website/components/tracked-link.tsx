"use client"
import Link from "next/link"
import { usePathname } from "next/navigation"
import type { ReactNode } from "react"
import { useAnalytics } from "../hooks/use-analytics"

interface TrackedLinkProps {
  href: string
  children: ReactNode
  className?: string
  trackingData?: {
    category?: string
    label?: string
    type?: "navigation" | "cta" | "external"
  }
  [key: string]: any
}

export default function TrackedLink({ href, children, className, trackingData = {}, ...props }: TrackedLinkProps) {
  const pathname = usePathname()
  const { trackNavigation, trackCTA } = useAnalytics()

  const handleClick = () => {
    const currentPage = pathname.split("/").pop() || "home"
    const destinationPage = href.split("/").pop() || "home"

    if (trackingData.type === "cta") {
      trackCTA(trackingData.label || children?.toString() || "Unknown CTA", currentPage, destinationPage)
    } else {
      trackNavigation(currentPage, destinationPage, trackingData.type || "link")
    }
  }

  return (
    <Link href={href} className={className} onClick={handleClick} {...props}>
      {children}
    </Link>
  )
}
