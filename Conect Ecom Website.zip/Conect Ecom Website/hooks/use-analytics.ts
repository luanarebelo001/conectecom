"use client"
import { useCallback } from "react"

// Tipos de eventos de analytics
export interface AnalyticsEvent {
  action: string
  category: string
  label?: string
  value?: number
  custom_parameters?: Record<string, any>
}

// Configuração de breadcrumb tracking
export interface BreadcrumbTrackingData {
  breadcrumb_level: number
  breadcrumb_path: string
  current_page: string
  destination_page: string
  navigation_type: "breadcrumb_click" | "home_click"
}

declare global {
  interface Window {
    gtag?: (...args: any[]) => void
    fbq?: (...args: any[]) => void
    dataLayer?: any[]
  }
}

export function useAnalytics() {
  // Função para enviar eventos para Google Analytics 4
  const trackGA4Event = useCallback((eventName: string, parameters: Record<string, any>) => {
    if (typeof window !== "undefined" && window.gtag) {
      window.gtag("event", eventName, {
        event_category: parameters.category,
        event_label: parameters.label,
        value: parameters.value,
        ...parameters.custom_parameters,
      })
    }
  }, [])

  // Função para enviar eventos para Facebook Pixel
  const trackFacebookEvent = useCallback((eventName: string, parameters: Record<string, any>) => {
    if (typeof window !== "undefined" && window.fbq) {
      window.fbq("trackCustom", eventName, {
        category: parameters.category,
        label: parameters.label,
        ...parameters.custom_parameters,
      })
    }
  }, [])

  // Função para enviar para DataLayer (GTM)
  const trackDataLayer = useCallback((eventName: string, parameters: Record<string, any>) => {
    if (typeof window !== "undefined" && window.dataLayer) {
      window.dataLayer.push({
        event: eventName,
        ...parameters,
      })
    }
  }, [])

  // Função principal para tracking de eventos
  const trackEvent = useCallback(
    (event: AnalyticsEvent) => {
      const eventData = {
        category: event.category,
        label: event.label,
        value: event.value,
        custom_parameters: event.custom_parameters,
      }

      // Enviar para todas as plataformas configuradas
      trackGA4Event(event.action, eventData)
      trackFacebookEvent(event.action, eventData)
      trackDataLayer(event.action, eventData)

      // Log para desenvolvimento
      if (process.env.NODE_ENV === "development") {
        console.log("📊 Analytics Event:", {
          action: event.action,
          ...eventData,
        })
      }
    },
    [trackGA4Event, trackFacebookEvent, trackDataLayer],
  )

  // Função específica para tracking de breadcrumbs
  const trackBreadcrumbClick = useCallback(
    (data: BreadcrumbTrackingData) => {
      trackEvent({
        action: "breadcrumb_navigation",
        category: "Navigation",
        label: `${data.current_page} → ${data.destination_page}`,
        value: data.breadcrumb_level,
        custom_parameters: {
          breadcrumb_level: data.breadcrumb_level,
          breadcrumb_path: data.breadcrumb_path,
          current_page: data.current_page,
          destination_page: data.destination_page,
          navigation_type: data.navigation_type,
          timestamp: new Date().toISOString(),
        },
      })
    },
    [trackEvent],
  )

  // Função para tracking de navegação geral
  const trackNavigation = useCallback(
    (from: string, to: string, method: string) => {
      trackEvent({
        action: "page_navigation",
        category: "Navigation",
        label: `${from} → ${to}`,
        custom_parameters: {
          navigation_method: method,
          source_page: from,
          destination_page: to,
          timestamp: new Date().toISOString(),
        },
      })
    },
    [trackEvent],
  )

  // Função para tracking de CTAs
  const trackCTA = useCallback(
    (ctaText: string, location: string, destination: string) => {
      trackEvent({
        action: "cta_click",
        category: "Engagement",
        label: ctaText,
        custom_parameters: {
          cta_text: ctaText,
          cta_location: location,
          cta_destination: destination,
          timestamp: new Date().toISOString(),
        },
      })
    },
    [trackEvent],
  )

  return {
    trackEvent,
    trackBreadcrumbClick,
    trackNavigation,
    trackCTA,
  }
}
